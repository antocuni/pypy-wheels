
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.15.3'
version = '1.15.3'
full_version = '1.15.3'
git_revision = 'f82c2b62d18b381baefc30f8e8d7788d08a0bd16'
release = True

if not release:
    version = full_version
