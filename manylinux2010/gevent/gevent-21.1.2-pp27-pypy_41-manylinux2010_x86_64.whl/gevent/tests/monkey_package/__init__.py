# -*- coding: utf-8 -*-
"""
Make a package.

This file has no other functionality. Individual modules in this package
are used for testing, often being run with 'python -m ...' in individual
test cases (functions).

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
